import 'package:flutter/material.dart';
import 'package:insta_assets_picker/insta_assets_picker.dart';
import 'package:social_media_flutter_bloc/features/addNewPost/add_filters.dart';
import 'package:social_media_flutter_bloc/features/addNewPost/add_new_post.dart';

class InitialScreen extends StatelessWidget {
  const InitialScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Center(
          child: ElevatedButton(
            style: ButtonStyle(
                backgroundColor: WidgetStatePropertyAll(Colors.purple)
            ),
            onPressed: () {
              // Navigator.of(context).push(MaterialPageRoute(builder: (context) => AddNewPost(),),);
              final theme = InstaAssetPicker.themeData(Theme.of(context).primaryColor);
              InstaAssetPicker.pickAssets(
                context,
                pickerConfig: InstaAssetPickerConfig(
                  pickerTheme: theme.copyWith(
                    canvasColor: Colors.black, // body background color
                    splashColor: Colors.grey, // ontap splash color
                    colorScheme: theme.colorScheme.copyWith(
                      background: Colors.black87, // albums list background color
                    ),
                    appBarTheme: theme.appBarTheme.copyWith(
                      backgroundColor: Colors.grey, // app bar background color
                      titleTextStyle: Theme.of(context)
                          .appBarTheme
                          .titleTextStyle
                          ?.copyWith(color: Colors.white), // change app bar title text style to be like app theme
                    ),
                    // edit `confirm` button style
                    textButtonTheme: TextButtonThemeData(
                      style: TextButton.styleFrom(
                        foregroundColor: Colors.blue,
                        disabledForegroundColor: Colors.red,
                      ),
                    ),
                  ),
                ),
                onCompleted: (data) {
                  Navigator.of(context).push(MaterialPageRoute(builder: (context) => AddFilters(cropStream: data,)));
                },
              );
            },
            child: Text("Start",style: TextStyle(color: Colors.white),),
          ),
        ),
      ),
    );
  }
}
