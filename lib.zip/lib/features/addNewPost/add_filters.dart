import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:image_editor_plus/image_editor_plus.dart';
import 'package:insta_assets_picker/insta_assets_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:photo_manager/photo_manager.dart';

class AddFilters extends StatelessWidget {
  final Stream<InstaAssetsExportDetails> cropStream;

  const AddFilters({super.key, required this.cropStream});

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.sizeOf(context).height - kToolbarHeight;
    return Scaffold(
      appBar: AppBar(title: const Text('New Post')),
      body: StreamBuilder<InstaAssetsExportDetails>(
        stream: cropStream,
        builder: (context, snapshot) => CropResultView(
          result: snapshot.data,
          heightFiles: height / 2,
          heightAssets: height / 4,
        ),
      ),
    );
  }
}

class CropResultView extends StatefulWidget {
  const CropResultView({
    super.key,
    required this.result,
    this.heightFiles = 300.0,
    this.heightAssets = 120.0,
  });

  final InstaAssetsExportDetails? result;
  final double heightFiles;
  final double heightAssets;

  @override
  State<CropResultView> createState() => _CropResultViewState();
}

class _CropResultViewState extends State<CropResultView> {
  final List<File> editedImages = [];

  List<InstaAssetsExportData?> get data => widget.result?.data ?? [];
  List<AssetEntity> get selectedAssets => widget.result?.selectedAssets ?? [];

  Future<void> _editImage(Uint8List imageBytes) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ImageEditor(image: imageBytes),
      ),
    );

    if (result != null && result is Uint8List) {
      final editedFile = await _saveEditedImage(result);
      setState(() {
        editedImages.add(editedFile);
      });
    }
  }

  Future<File> _saveEditedImage(Uint8List bytes) async {
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/${DateTime.now().millisecondsSinceEpoch}.jpg');
    return await file.writeAsBytes(bytes);
  }

  Widget _buildTitle(String title, int length) {
    return SizedBox(
      height: 20.0,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Text(title),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 10.0),
            padding: const EdgeInsets.all(4.0),
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.deepPurpleAccent,
            ),
            child: Text(
              length.toString(),
              style: const TextStyle(color: Colors.white, height: .7),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCroppedAssetsListView(BuildContext context) {
    if (widget.result?.progress == null) {
      return const SizedBox.shrink();
    }

    final double progress = widget.result!.progress;

    return Expanded(
      child: Stack(
        alignment: Alignment.center,
        children: [
          ListView.builder(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            scrollDirection: Axis.horizontal,
            itemCount: data.length,
            itemBuilder: (BuildContext _, int index) {
              return Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 8.0,
                  vertical: 16.0,
                ),
                child: Stack(
                  children: [
                    GestureDetector(
                      onTap: () async {
                        if (data[index]?.croppedFile != null) {
                          final bytes = await data[index]!.croppedFile!.readAsBytes();
                          final result = await Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => FullScreenImage(imageBytes: bytes),
                              )
                          );

                              if (result != null && result is Uint8List) {
                            final editedFile = await _saveEditedImage(result);
                            setState(() => editedImages.add(editedFile));
                          }
                        }
                      },
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4.0),
                        ),
                        child: data[index]?.croppedFile != null
                            ? Image.file(data[index]!.croppedFile!)
                            : Container(),
                      ),
                    ),
                    if (data[index]?.croppedFile != null)
                      Positioned(
                        top: 0,
                        right: 0,
                        child: IconButton(
                          icon: const Icon(Icons.edit, color: Colors.white),
                          onPressed: () async {
                            final bytes = await data[index]!.croppedFile!.readAsBytes();
                            _editImage(bytes);
                          },
                        ),
                      ),
                  ],
                ),
              );
            },
          ),
          if (progress < 1.0)
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: Theme.of(context).scaffoldBackgroundColor.withOpacity(.5),
                ),
              ),
            ),
          if (progress < 1.0)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: ClipRRect(
                borderRadius: const BorderRadius.all(Radius.circular(5)),
                child: SizedBox(
                  height: 6,
                  child: LinearProgressIndicator(
                    value: progress,
                    semanticsLabel: '${progress * 100}%',
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        AnimatedContainer(
          duration: kThemeChangeDuration,
          curve: Curves.easeInOut,
          height: data.isNotEmpty ? widget.heightFiles : 40.0,
          child: Column(
            children: <Widget>[
              _buildTitle('Selected images', data.length),
              _buildCroppedAssetsListView(context),
            ],
          ),
        ),
        if (editedImages.isNotEmpty)
          Column(
            children: [
              const Text("Edited Images Preview:"),
              SizedBox(
                height: 100,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: editedImages.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: Image.file(editedImages[index]),
                    );
                  },
                ),
              ),
            ],
          ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8.0),
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: widget.result != null &&
                  widget.result?.progress != null &&
                  widget.result!.progress >= 1 &&
                  selectedAssets.isNotEmpty
                  ? () {
                final List<File> finalImages = data.asMap().entries.map((entry) {
                  return editedImages[entry.key] ?? entry.value!.croppedFile!;
                }).toList();

                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => PostDisplayScreen(images: finalImages),
                  ),
                );
              }
                  : null,
              icon: const Icon(Icons.cloud_upload),
              label: const Text('Create Post'),
            )
          ),
        ),
      ],
    );
  }
}

class FullScreenImage extends StatefulWidget {
  final Uint8List imageBytes;

  const FullScreenImage({super.key, required this.imageBytes});

  @override
  State<FullScreenImage> createState() => _FullScreenImageState();
}

class _FullScreenImageState extends State<FullScreenImage> {
  int selectedFilterIndex = 0;
  final GlobalKey _repaintKey = GlobalKey();

  final List<Map<String, dynamic>> filters = [
    {
      'name': 'Filter 1',
      'matrix': ColorFilter.matrix([
        0.7, 0.0, 0.0, 0.0, 0.0,
        0.0, 0.9, 0.0, 0.0, 0.0,
        0.0, 0.0, 0.8, 0.0, 0.0,
        0.0, 0.0, 0.0, 1.0, 0.0,
      ]),
    },
    {
      'name': 'Filter 2',
      'matrix': ColorFilter.matrix([
        1.2, 0.0, 0.0, 0.0, 0.0,
        0.0, 1.0, 0.0, 0.0, 0.0,
        0.0, 0.0, 0.9, 0.0, 0.0,
        0.0, 0.0, 0.0, 1.0, 0.0,
      ]),
    },
    {
      'name': 'Filter 3',
      'matrix': ColorFilter.matrix([
        0.5, 0.5, 0.5, 0.0, 0.0,
        0.5, 0.5, 0.5, 0.0, 0.0,
        0.5, 0.5, 0.5, 0.0, 0.0,
        0.0, 0.0, 0.0, 1.0, 0.0,
      ]),
    },
    {
      'name': 'Filter 4',
      'matrix': ColorFilter.matrix([
        1.0, 0.0, 0.0, 0.0, 0.0,
        0.0, 0.8, 0.0, 0.0, 0.0,
        0.0, 0.0, 0.8, 0.0, 0.0,
        0.0, 0.0, 0.0, 1.0, 0.0,
      ]),
    },
  ];

  Future<void> _saveAndReturn() async {
    try {
      final RenderRepaintBoundary boundary =
      _repaintKey.currentContext!.findRenderObject()! as RenderRepaintBoundary;
      final ui.Image image = await boundary.toImage();
      final ByteData? byteData =
      await image.toByteData(format: ui.ImageByteFormat.png);
      final Uint8List bytes = byteData!.buffer.asUint8List();

      if (!mounted) return;
      Navigator.pop(context, bytes);
    } catch (e) {
      print('Error saving image: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: TextButton(
              onPressed: _saveAndReturn,
              child: const Text('Next', style: TextStyle(color: Colors.white)),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: RepaintBoundary(
              key: _repaintKey,
              child: InteractiveViewer(
                maxScale: 5.0,
                child: ColorFiltered(
                  colorFilter: filters[selectedFilterIndex]['matrix'],
                  child: Image.memory(widget.imageBytes),
                ),
              ),
            ),
          ),
          SizedBox(
            height: 120,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: filters.length,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () => setState(() => selectedFilterIndex = index),
                  child: Container(
                    margin: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: selectedFilterIndex == index
                            ? Colors.white
                            : Colors.transparent,
                        width: 2,
                      ),
                    ),
                    child: ColorFiltered(
                      colorFilter: filters[index]['matrix'],
                      child: Image.memory(
                        widget.imageBytes,
                        width: 80,
                        height: 80,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class PostDisplayScreen extends StatelessWidget {
  final List<File> images;
  final String username;

  const PostDisplayScreen({
    super.key,
    required this.images,
    this.username = 'John Karter',
  });

  @override
  Widget build(BuildContext context) {
    final postedTime = DateTime.now();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // User Profile Section
            _buildUserProfile(postedTime),

            // Image Carousel
            _buildImageCarousel(context),

            // Action Buttons
            _buildActionButtons(),
          ],
        ),
      ),
    );
  }

  Widget _buildUserProfile(DateTime postedTime) {
    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: Row(
        children: [
          const CircleAvatar(
            radius: 20,
            backgroundImage: NetworkImage('https://example.com/profile.png'),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                username,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
              Text(
                _timeAgo(postedTime),
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildImageCarousel(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.6,
      child: CarouselSlider(
        options: CarouselOptions(
          enlargeCenterPage: true,
          enableInfiniteScroll: images.length > 1,
          viewportFraction: 1,
        ),
        items: images.map((file) {
          return Builder(
            builder: (BuildContext context) {
              return Image.file(
                file,
                fit: BoxFit.cover,
                width: MediaQuery.of(context).size.width,
              );
            },
          );
        }).toList(),
      ),
    );
  }

  Widget _buildActionButtons() {
    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.favorite_border),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.comment_outlined),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.send),
            onPressed: () {},
          ),
        ],
      ),
    );
  }

  String _timeAgo(DateTime date) {
    final duration = DateTime.now().difference(date);
    if (duration.inDays > 365) return '${(duration.inDays / 365).floor()}y ago';
    if (duration.inDays > 30) return '${(duration.inDays / 30).floor()}m ago';
    if (duration.inDays > 0) return '${duration.inDays}d ago';
    if (duration.inHours > 0) return '${duration.inHours}h ago';
    if (duration.inMinutes > 0) return '${duration.inMinutes}m ago';
    return 'Just now';
  }
}
